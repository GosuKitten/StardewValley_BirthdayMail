BirthdayMail v1.2.2 by Kathryn Hazuka

Instalation: (if new installation)
1. Extract folders to Stardew Valley's root directory
2. Merge all folders
3. Replace all files
4. Play!

I have included a backup of the original mail.xnb just in case.

The sorce code can be found here: https://github.com/KathrynHazuka/StardewValley_BirthdayMail
If you like the mod, please leave a comment on the Nexus Mods and/or Chucklefigh community forums.

Change Log:

1.0.0: 
base release.

1.1.0: 
fixed issue with mail not showing up on the first day if mod is installed on the day of an NPC birthday.

1.1.1: 
fixed possible issue with mail being resent if game loads the game back up after saving and quitting.

1.2.0:
grammatical and phrasing fixes.

1.2.1:
update to game version 1.1

1.2.2:
update to SMAPI version 1.0+

1.3.0:
update to SMAPI version 2.0+

1.3.1:
update to SMAPI version 2.5+

1.4.0:
update to game version 1.3.28 (Mutiplayer compatibility)

Thank you and enjoy!~
