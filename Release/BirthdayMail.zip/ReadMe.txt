BirthdayMail v1.0.0 by Kathryn Hazuka

Instalation:
1. Extract folders to Stardew Valley's root directory
2. Merge all folders
3. Replace all files
4. Play!

I have included a backup of the original mail.xnb just in case.

The sorce code can be found here: https://github.com/KathrynHazuka/StardewValley_BirthdayMail
If you like the mod, please leave a comment on the Nexus Mods and/or Chucklefigh community forums.

Thank you and enjoy!~
