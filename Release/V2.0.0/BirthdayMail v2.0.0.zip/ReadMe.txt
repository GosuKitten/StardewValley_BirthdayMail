BirthdayMail v2.0.0 by Kathryn Hazuka

Instalation:
1. Extract folders to Stardew Valley's root directory
2. Merge the mod folder
3. Replace all files (if updating)
4. Play!

The sorce code can be found here: https://github.com/KathrynHazuka/StardewValley_BirthdayMail
If you like the mod, please leave a comment on the Nexus Mods and/or Chucklefish community forums.
If you'd like to donate: Paypay - kathrynhazuka@hotmail.com

-----------------------------------------------------------------------------------------------------------

Change Log:

1.0.0: 
base release.

---

1.1.0: 
fixed issue with mail not showing up on the first day if mod is installed on the day of an NPC birthday.

---

1.1.1: 
fixed possible issue with mail being resent if game loads the game back up after saving and quitting.

---

1.2.0:
grammatical and phrasing fixes.

---

1.2.1:
update to game version 1.1

---

1.2.2:
update to SMAPI version 1.0+

---

1.3.0:
update to SMAPI version 2.0+

---

1.3.1:
update to SMAPI version 2.5+

---

1.4.0:
update to game version 1.3.28 (Mutiplayer compatibility)

---

1.5.0:
update to use Pathoschild's Content Patcher for end user convenience!

---

1.5.1:
added chinese translation to mail content

---

2.0.0:
update to game version 1.4.3 and SMAPI version 3.0+

added Russian and Portuguese translations. 
Portuguese translation checked by @Karmylla on Nexus mods. Please check out their mods!

updated implementation of Content Patcher for compatibility with other mods

-----------------------------------------------------------------------------------------------------------

Thank you and enjoy!~
